

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
     
    <title>Как начать инвестировать (для начинающих)</title>
    <!-- bootstrap css -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>
<!-- body -->
<body class="main-layout">

<!-- header -->
<header>
    <!-- header inner -->
    <div class="header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                    <div class="full">
                        <div class="center-desk">
                            <div class="logo">
                                <a href="index.php"><h2>Депозит</h2></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                    <div class="header_information">
                        <nav class="navigation navbar navbar-expand-md navbar-dark ">
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarsExample04">
                                <ul class="navbar-nav mr-auto">
                                    <li class="nav-item">
                                        <a class="nav-link" href="index.php">Главная</a>
                                    </li>
                                    <li class="nav-item active">
                                        <a class="nav-link" href="blog.php">Статьи</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="contact.php">Контакты</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="policy.php">Политика конфиденциальности</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="terms.php">Условия и положения</a>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- end header inner -->
<!-- end header -->
<!-- banner -->

<!-- about -->
<div id="about"  class="about">
    <div class="container">
        <h1>Как начать инвестировать (для начинающих)</h1>
        <div class="content">
            <img src="./img/kelly-sikkema-g_91h-3qzoa-unsplash.jpg" alt="" class="post-img">
            <p><strong></strong> Инвестиции - это захватывающая и очень сложная концепция для многих людей.Хотя тема вложения денег не так уж сложна для подавляющего большинства людей. В этой статье мы поговорим о том, как начать инвестировать свои деньги (для начинающих).Первое, что вам нужно сделать, это понять, во что именно вы хотите вложить свои деньги.Второе - создать "финансовую подушку".Именно эта "подушка" достаточного размера позволит вам начать инвестировать.В-третьих, нужно погасить существующие кредиты.Четвертая вещь заключается в том, чтобы инвестируйте свои деньги.Я не ошибусь, но многие люди, которые получают зарплату, не делают инвестиций. У них нет необходимой суммы денег для этой цели. 1) Прочтите мою статью "Куда НЕ СТОИТ вкладывать деньги? ТОП-3 самых опасных мест для денег". 2) Прочтите мою статью "Какие навыки вам нужны, чтобы стать богатым".</p>
        </div>
    </div>
</div>
<!-- end about -->

<!--  footer -->
<footer>
    <div class="footer">
        <div class="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <p>©
                            <script>document.write(new Date().getFullYear())</script> All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<div class='cookie-banner'>
    <p>
        Сайт использует файлы cookie. Они позволяют узнавать вас и получать информацию о вашем пользовательском опыте.Продолжая просмотр сайта, я соглашаюсь с использованием файлов cookie владельцем сайта в соответствии с <a target="_blank" href="https://en.wikipedia.org/wiki/HTTP_cookie">Политикой cookie</a>
    </p>
    <button class='close-cookie'>&times;</button>
</div>
<script>
    window.onload = function () {
        $('.close-cookie').click(function () {
            $('.cookie-banner').fadeOut();
        })
    }
</script>
<script>
    let elems = document.querySelectorAll('.server-name');
    elems.forEach((elem) => {
        elem.innerHTML = window.location.hostname
    })
</script>
<!-- end footer -->
<!-- Javascript files-->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>

<!-- sidebar -->
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
</body>
</html>

