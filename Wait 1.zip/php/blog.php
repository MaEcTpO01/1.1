

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
     
    <title>Статьи</title>
    <!-- bootstrap css -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>
<!-- body -->
<body class="main-layout">
<!-- header -->
<header>
    <!-- header inner -->
    <div class="header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                    <div class="full">
                        <div class="center-desk">
                            <div class="logo">
                                <a href="index.php"><h2>Финансовая грамотность</h2></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                    <div class="header_information">
                        <nav class="navigation navbar navbar-expand-md navbar-dark ">
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarsExample04">
                                <ul class="navbar-nav mr-auto">
                                    <li class="nav-item">
                                        <a class="nav-link" href="index.php">Главная</a>
                                    </li>
                                    <li class="nav-item active">
                                        <a class="nav-link" href="blog.php">Статьи</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="contact.php">Контакты</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="policy.php">Политика конфиденциальности</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="terms.php">Условия и положения</a>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- end header inner -->
<!-- end header -->
<!-- banner -->

<!-- about -->
<div id="about"  class="about">
    <div class="container">
        <h1>Статьи</h1>
        
        <div class="row d_flex py-4 mb-2">
            <div class="col-md-7">
                <div class="titlepage">
                    <a href="IpF6WwLbbH9ciERAAXxs.php"><h2>Как начать инвестировать (для начинающих)</h2></a>
                    <span></span>
                    <p><strong></strong> Инвестиции - это захватывающая и очень сложная концепция для многих людей.Хотя тема вложения денег не так уж сложна для подавляющего большинст...</p>
                    <a href="IpF6WwLbbH9ciERAAXxs.php" class="read_more">Читать далее <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
                </div>
            </div>
            <div class="col-md-5">
                <div class="about_img">
                    <figure><img src=""/></figure>
                </div>
            </div>
        </div>
        

        <div class="row d_flex py-4 mb-2">
            <div class="col-md-7">
                <div class="titlepage">
                    <a href="Z1u6U3MxbApXaHjiII.php"><h2>Три принципа, которые обязательн...</h2></a>
                    <span></span>
                    <p><strong></strong> Мы все слышали, что необходимо "начать с чистого листа" и избавиться от всех вредных привычек, чтобы обрести финансовое процветание.Просто хочу...</p>
                    <a href="Z1u6U3MxbApXaHjiII.php" class="read_more">Читать далее <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
                </div>
            </div>
            <div class="col-md-5">
                <div class="about_img">
                    <figure><img src=""/></figure>
                </div>
            </div>
        </div>
        

        <div class="row d_flex py-4 mb-2">
            <div class="col-md-7">
                <div class="titlepage">
                    <a href="c37a009f3692cdcc3b9dcfa992970e1b.php"><h2>Мощный фактор роста личных доход...</h2></a>
                    <span></span>
                    <p><strong></strong> Кризис, вызванный коронавирусом, представляет реальную угрозу не только врачам, медсестрам и обычному состоянию здоровья, но и финансовым рын...</p>
                    <a href="c37a009f3692cdcc3b9dcfa992970e1b.php" class="read_more">Читать далее <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
                </div>
            </div>
            <div class="col-md-5">
                <div class="about_img">
                    <figure><img src=""/></figure>
                </div>
            </div>
        </div>
        

        <div class="row d_flex py-4 mb-2">
            <div class="col-md-7">
                <div class="titlepage">
                    <a href="a17f41c71ddc3afcf808b28602cb2af3.php"><h2>Коронавирус выявил слабые места ...</h2></a>
                    <span></span>
                    <p><strong></strong> Вирус COVID-19 сумел поставить весь мир "на колени" и заставил нас столкнуться с фундаментальной проблемой современности: как застраховать финанс...</p>
                    <a href="a17f41c71ddc3afcf808b28602cb2af3.php" class="read_more">Читать далее <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
                </div>
            </div>
            <div class="col-md-5">
                <div class="about_img">
                    <figure><img src=""/></figure>
                </div>
            </div>
        </div>
        

    </div>
</div>
<!-- end about -->

<!--  footer -->
<footer>
    <div class="footer">
        <div class="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <p>©
                            <script>document.write(new Date().getFullYear())</script> All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<div class='cookie-banner'>
    <p>
        Сайт использует файлы cookie. Они позволяют узнавать вас и получать информацию о вашем пользовательском опыте.Продолжая просмотр сайта, я соглашаюсь с использованием файлов cookie владельцем сайта в соответствии с <a target="_blank" href="https://en.wikipedia.org/wiki/HTTP_cookie">Политикой cookie</a>
    </p>
    <button class='close-cookie'>&times;</button>
</div>
<script>
    window.onload = function () {
        $('.close-cookie').click(function () {
            $('.cookie-banner').fadeOut();
        })
    }
</script>
<script>
    let elems = document.querySelectorAll('.server-name');
    elems.forEach((elem) => {
        elem.innerHTML = window.location.hostname
    })
</script>
<!-- end footer -->
<!-- Javascript files-->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>

<!-- sidebar -->
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
</body>
</html>

